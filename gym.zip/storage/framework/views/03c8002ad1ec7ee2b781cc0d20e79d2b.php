<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4"><?php echo e($titlePage); ?></h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="thead-dark">
                <tr>
                    <th>اسم العميل</th>
                    <th>رقم الهاتف</th>
                    <th>قيمة الاشتراك</th>
                    <th>تاريخ البدء</th>
                    <th>تاريخ الانتهاء</th>
                    <th>عدد استخدام المشاية</th>
                    <th>ملاحظات</th>
                    <th>إجراءات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->phone ?? 'لا يوجد'); ?></td>
                        <?php if($user->membership): ?>
                            <td><?php echo e($user->membership->price); ?></td>
                            <td><?php echo e($user->membership->start_date); ?></td>
                            <td><?php echo e($user->membership->end_date); ?></td>
                            <td><?php echo e($user->membership->walker_count); ?></td>
                            <td><?php echo e($user->membership->note); ?></td>
                        <?php else: ?>
                            <td colspan="5" class="text-center">لا توجد عضوية</td>
                        <?php endif; ?>
                        <td>
                            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning btn-sm">تعديل</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gym\resources\views/users/index.blade.php ENDPATH**/ ?>