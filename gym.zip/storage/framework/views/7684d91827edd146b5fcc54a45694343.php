<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">تعديل المستخدم: <?php echo e($user->name); ?></h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name">اسم العميل</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>
            </div>

            <div class="form-group">
                <label for="phone">رقم الهاتف</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>">
            </div>

            <h3>بيانات العضوية (اختياري)</h3>

            <div class="form-group">
                <label for="price">السعر</label>
                <input type="number" class="form-control" id="price" name="price" value="<?php echo e($user->membership->price ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="start_date">تاريخ البدء</label>
                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo e($user->membership->start_date ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="end_date">تاريخ الانتهاء</label>
                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo e($user->membership->end_date ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="walker_count">عدد استخدام المشاية</label>
                <input type="number" class="form-control" id="walker_count" name="walker_count" value="<?php echo e($user->membership->walker_count ?? ''); ?>">
            </div>

            <div class="form-group">
                <label for="note">ملاحظات</label>
                <textarea class="form-control" id="note" name="note"><?php echo e($user->membership->note ?? ''); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gym\resources\views/users/edit.blade.php ENDPATH**/ ?>