<?php $__env->startSection('content'); ?>
    <h1>Memberships</h1>
    <a href="<?php echo e(route('memberships.create')); ?>" class="btn btn-primary">Add Membership</a>
    <table class="table">
        <thead>
        <tr>
            <th>User</th>
            <th>Type</th>
            <th>Start Date</th>
            <th>End Date</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($membership->user->name); ?></td>
                <td><?php echo e($membership->type); ?></td>
                <td><?php echo e($membership->start_date); ?></td>
                <td><?php echo e($membership->end_date); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gym\resources\views/memberships/index.blade.php ENDPATH**/ ?>