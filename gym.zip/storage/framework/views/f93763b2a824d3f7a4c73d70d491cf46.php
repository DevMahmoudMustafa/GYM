<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                <a href="<?php echo e(route('users.index')); ?>" class="text-decoration-none">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">عدد المستخدمين</h5>
                                    <h3 class="card-text"><?php echo e($userCount); ?></h3>
                                </div>
                                <div>
                                    <i class="fas fa-users fa-3x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                <a href="<?php echo e(route('users.active-membership')); ?>" class="text-decoration-none">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">العضويات النشطة</h5>
                                    <h3 class="card-text"><?php echo e($activeMembershipsCount); ?></h3>
                                </div>
                                <div>
                                    <i class="fas fa-check-circle fa-3x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                <a href="<?php echo e(route('users.expiring-soon-membership')); ?>" class="text-decoration-none">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">العضويات القريبة من الانتهاء</h5>
                                    <h3 class="card-text"><?php echo e($expiringSoonMembershipsCount); ?></h3>
                                </div>
                                <div>
                                    <i class="fas fa-hourglass-half fa-3x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                <a href="<?php echo e(route('users.expired-membership')); ?>" class="text-decoration-none">
                    <div class="card text-white bg-danger">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">العضويات المنتهية</h5>
                                    <h3 class="card-text"><?php echo e($expiredMembershipsCount); ?></h3>
                                </div>
                                <div>
                                    <i class="fas fa-times-circle fa-3x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gym\resources\views/dashboard/index.blade.php ENDPATH**/ ?>